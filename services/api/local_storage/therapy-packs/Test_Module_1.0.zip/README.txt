Therapy Module: Test Module
================================

Description: For checksum testing
Type: test
Age Range: N/A - N/A months
Steps: 1

This is an offline therapy module pack for the SAHAAY platform.
For more information, visit: https://github.com/sahaay/platform

Files:
- module.json: Module metadata
- steps.json: Step-by-step therapy instructions
- README.txt: This file

Media files referenced in steps.json should be downloaded separately
using the media_references URLs.
